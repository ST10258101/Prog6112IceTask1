/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication51;

import java.util.Scanner;

/**
 *
 * @author Vinay
 */
public class JavaApplication51 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Bird brd = new Bird();
        Reptile rept = new Reptile();

        System.out.println("Enter details for Bird:");
        brd.input();

        System.out.println("Enter details for Reptile:");
        rept.input();

        System.out.println("\nBird details:");
        brd.output();

        System.out.println("\nReptile details:");
        rept.output();
        
         Scanner scanner = new Scanner(System.in);
    System.out.println("Press Enter to exit...");
    scanner.nextLine();
    }
}






